# Estado da implementação

| Área | Implementado | Pendente |
|---|---|---|
| Host | VST3 estéreo; 64 parâmetros IDs v1 | Validação em DAW Windows real |
| Áudio | Ganhos L/R, Level Fast/Slow, rotas INPUT/REPRO/SYNC, MASTERSAFE; rampa de ganhos | Fita, bias, EQ, perda de cabeças, SYNC narrow/wide |
| Referências | Fluxo/VU, calibração e velocidades em funções isoladas | Integrar medição VU/calibrate ao plugin |
| Presets | 90 alinhamentos, programas do host, JSONs de fábrica | Diferenças de timbre dependem do DSP; import/export UI, usuário, busca/A-B |
| Estado | APVTS, schema v1, rejeição de estados incompletos/inválidos | Migrações de versões futuras |
| Interface | Editor técnico com seletor de programas e avisos | Painel gráfico conceitual, medidores, animações, abas |
| Tempo real | Ganhos suavizados, denormais, sem construção de strings ou alocação explícita no processBlock | Auditoria RT completa/automação sob carga |
| Transporte | Parâmetros reservados/persistidos | Host transport, varispeed, flutter e ruído |

O mapeamento documental anterior permanece como especificação pretendida. Não interpretar uma entrada nesse documento como recurso já implementado. Todos os controles sem DSP são marcados `[PENDING]` no editor, inclusive tape_type/EQ. `[VISUAL]` marca controles sem efeito sonoro por requisito.

O número de programa indica o último preset carregado, mesmo após edição manual de parâmetros; o estado completo, não esse número, determina os ajustes restaurados.
