#include "../src/PluginProcessor.h"
#include <iostream>
#include <stdexcept>
void check(bool b){if(!b)throw std::runtime_error("processor check failed");}
void set(A800Processor& p,const char* id,float v){auto* x=p.state.getParameter(id);check(x!=nullptr);x->setValueNotifyingHost(x->convertTo0to1(v));}
int main(int argc,char**){
 A800Processor p;juce::MidiBuffer midi;
 check(p.getParameters().size()==64);check(p.getNumPrograms()==90);
 for(int i=0;i<90;++i){p.setCurrentProgram(i);check(p.getCurrentProgram()==i);check(p.getProgramName(i).isNotEmpty());}
 p.setCurrentProgram(0);
 for(double sr:{44100.,48000.,96000.,192000.}) {
  p.prepareToPlay(sr,512);juce::AudioBuffer<float> b(2,512);
  for(int ch=0;ch<2;++ch)for(int n=0;n<512;++n)b.setSample(ch,n,0.125f);
  p.processBlock(b,midi);check(std::abs(b.getSample(0,511)-0.125f)<1e-6f);
 }
 set(p,"ch1_rec_input_level",3);set(p,"ch2_rec_input_level",-3);
 p.prepareToPlay(48000,512);juce::AudioBuffer<float> b(2,512);
 for(int ch=0;ch<2;++ch)for(int n=0;n<512;++n)b.setSample(ch,n,0.1f);
 p.processBlock(b,midi);check(b.getSample(0,511)>b.getSample(1,511));
 juce::MemoryBlock state;p.getStateInformation(state);
 set(p,"ch1_rec_input_level",0);p.setStateInformation(state.getData(),int(state.getSize()));
 check(p.state.getRawParameterValue("ch1_rec_input_level")->load()==3);
 const char invalid[]="invalid";p.setStateInformation(invalid,sizeof(invalid));
 check(p.state.getRawParameterValue("ch1_rec_input_level")->load()==3);
 set(p,"mastersafe",1);p.prepareToPlay(48000,512);
 for(int ch=0;ch<2;++ch)for(int n=0;n<512;++n)b.setSample(ch,n,0.2f);
 p.processBlock(b,midi);check(b.getSample(0,511)==0.2f && b.getSample(1,511)==0.2f);
 if(argc>1) {juce::ScopedJuceInitialiser_GUI gui;std::unique_ptr<juce::AudioProcessorEditor> e(p.createEditorIfNeeded());check(e!=nullptr);e->setSize(1000,700);e->addToDesktop(0);e->setVisible(true);e->setVisible(false);}
 std::cout<<"PASS: 64 parameters, 90 programs, four sample rates, L/R gain, state restore, malformed state, MASTERSAFE\n";
}
