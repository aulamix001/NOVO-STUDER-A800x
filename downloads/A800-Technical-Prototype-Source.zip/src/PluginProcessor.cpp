#include "PluginProcessor.h"
#include "dsp/TapeConstants.h"
#include "GeneratedParameters.h"

A800Processor::A800Processor()
 : AudioProcessor(BusesProperties().withInput("Stereo input",juce::AudioChannelSet::stereo(),true)
                                  .withOutput("Stereo output",juce::AudioChannelSet::stereo(),true)),
   state(*this,nullptr,"A800_STATE",makeLayout()) {
 safe=state.getRawParameterValue("mastersafe");
 speed=state.getRawParameterValue("speed_select");
 sensitivity=state.getRawParameterValue("in_sens_plus7");
 for(int i=0;i<2;++i) {
  const auto prefix="ch"+juce::String(i+1)+"_";
  auto get=[&](const juce::String& suffix) {return state.getRawParameterValue(prefix+suffix);};
  auto& c=channels[size_t(i)];
  c.source=get("src"); c.input=get("rec_input_level");
  c.out1=get("rep_out1_level");c.out2=get("syn_out2_level");
  for(int s=0;s<2;++s) {
   const juce::String part=s==0 ? "slow_level" : "fast_level";
   c.record[s]=get("rec_"+part);c.repro[s]=get("rep_"+part);c.sync[s]=get("syn_"+part);
  }
 }
 setLatencySamples(0); // No tape model or oversampling exists in this technical prototype.
}
bool A800Processor::isBusesLayoutSupported(const BusesLayout& b) const {
 return b.getMainInputChannelSet()==juce::AudioChannelSet::stereo()
     && b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo();
}
float A800Processor::targetGain(const Channel& c) const noexcept {
 if(safe->load()>=0.5f) return 1.f;
 const int src=juce::jlimit(0,2,int(c.source->load()));
 float db=c.input->load()+(sensitivity->load()>=0.5f ? 7.f : 0.f);
 if(src!=0) {
  const int active=speed->load()>=0.5f ? 1 : 0;
  db+=c.record[active]->load();
  db+=src==1 ? c.repro[active]->load()+c.out1->load() : c.sync[active]->load()+c.out2->load();
 }
 return juce::Decibels::decibelsToGain(db);
}
void A800Processor::prepareToPlay(double sr,int) {
 for(auto& c:channels) {c.gain.reset(sr,0.02);c.gain.setCurrentAndTargetValue(targetGain(c));}
}
void A800Processor::processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer&) {
 juce::ScopedNoDenormals guard;
 for(int ch=0;ch<b.getNumChannels();++ch) {
  if(ch>=2) {b.clear(ch,0,b.getNumSamples());continue;}
  auto& c=channels[size_t(ch)];c.gain.setTargetValue(targetGain(c));
  auto* data=b.getWritePointer(ch);
  for(int i=0;i<b.getNumSamples();++i) data[i]*=c.gain.getNextValue();
 }
}
void A800Processor::setCurrentProgram(int index) {
 if(index<0 || index>=90) return;
 const auto& p=factoryPresets[size_t(index)];
 for(size_t i=0;i<parameterIds.size();++i)
  if(auto* param=state.getParameter(parameterIds[i]))
   param->setValueNotifyingHost(param->convertTo0to1(p.values[i]));
 currentProgram.store(index);
}
const juce::String A800Processor::getProgramName(int index) {
 return index>=0 && index<90 ? juce::String::fromUTF8(factoryPresets[size_t(index)].name) : juce::String{};
}
void A800Processor::getStateInformation(juce::MemoryBlock& b) {
 auto tree=state.copyState(); tree.setProperty("schema_version",1,nullptr);
 tree.setProperty("program",currentProgram.load(),nullptr);
 if(auto xml=tree.createXml()) copyXmlToBinary(*xml,b);
}
void A800Processor::setStateInformation(const void* data,int size) {
 auto xml=getXmlFromBinary(data,size);
 if(!xml || !xml->hasTagName("A800_STATE")) return;
 auto tree=juce::ValueTree::fromXml(*xml);
 if(int(tree.getProperty("schema_version",0))!=1) return;
 // Validate fully before replacing state; reject unknown, missing, duplicate or invalid values.
 if(tree.getNumChildren()!=int(parameterIds.size())) return;
 for(auto id:parameterIds) {
  auto* p=state.getParameter(id); int matches=0;
  for(auto child:tree) if(child.getProperty("id").toString()==id) {
   ++matches;
   if(!child.hasProperty("value")) return;
   const float v=float(child.getProperty("value"));
   const auto range=p->getNormalisableRange();
   if(!std::isfinite(v) || v<range.start || v>range.end) return;
  }
  if(matches!=1) return;
 }
 const int program=int(tree.getProperty("program",0));
 if(program<0 || program>=90) return;
 state.replaceState(tree);currentProgram.store(program);
}
namespace {
class Editor final : public juce::AudioProcessorEditor, private juce::Timer {
 A800Processor& proc;
 juce::Label notice;
 juce::ComboBox programs;
 juce::GenericAudioProcessorEditor controls;
public:
 explicit Editor(A800Processor& p):AudioProcessorEditor(p),proc(p),controls(p) {
  notice.setText("TECHNICAL PROTOTYPE - gain/routing only. Tape sound and [PENDING] controls NOT implemented.",juce::dontSendNotification);
  notice.setColour(juce::Label::textColourId,juce::Colours::orange);
  for(int i=0;i<p.getNumPrograms();++i) programs.addItem(p.getProgramName(i),i+1);
  programs.setSelectedId(p.getCurrentProgram()+1,juce::dontSendNotification);
  programs.onChange=[this]{proc.setCurrentProgram(programs.getSelectedId()-1);};
  addAndMakeVisible(notice);addAndMakeVisible(programs);addAndMakeVisible(controls);
  setResizable(true,true);setResizeLimits(700,450,1500,1600);setSize(900,850);startTimerHz(5);
 }
 void timerCallback() override {programs.setSelectedId(proc.getCurrentProgram()+1,juce::dontSendNotification);}
 void resized() override {
  auto r=getLocalBounds().reduced(10);notice.setBounds(r.removeFromTop(50));
  programs.setBounds(r.removeFromTop(35));r.removeFromTop(10);controls.setBounds(r);
 }
};
}
juce::AudioProcessorEditor* A800Processor::createEditor() {return new Editor(*this);}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {return new A800Processor();}
